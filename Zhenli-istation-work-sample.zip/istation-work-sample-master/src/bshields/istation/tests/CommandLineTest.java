package bshields.istation.tests;

import static java.lang.System.out;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import bshields.istation.controllers.VendingMachineController;
import bshields.istation.interfaces.Shelf;
import bshields.istation.interfaces.ShelfSlot;
import bshields.istation.interfaces.VendingMachine;
import bshields.istation.models.DefaultShelf;
import bshields.istation.models.DefaultShelfSlot;
import bshields.istation.models.DefaultVendingMachine;
import bshields.istation.models.DefaultVendingMachineItem;
import bshields.istation.models.Message;
import bshields.istation.views.VendingMachineConsoleView;

/**
 * An interactive console application which can be used to test most of the features of the various vending machine classes.
 * 
 * @author 
 */
public class CommandLineTest {
	private static VendingMachineController controller;
	private static Scanner in;
	
	/**
	 * Program entry point
	 * 
	 * @param args command-line arguments; not used
	 */
	public static void main(String[] args) {
		in = new Scanner(System.in);
		
		setupMachine();
		handleInput();
	}
	
	private static void handleInput() {
		int selection = 0;
		String line = "";
		do {
			printMenu();
			try { selection = Integer.parseInt(in.nextLine()); }
			catch(NumberFormatException nfe) { continue; }
			
			switch (selection) {
				case 1:
					controller.lookAtAvailableItems();
					out.print("Press [Enter]...");
					in.nextLine();
					break;
				case 2:
					out.print("Enter dollar amount: ");
					line = in.nextLine();
					line = line.replaceAll("[^0-9.]", "");
					try { controller.addCash(new BigDecimal(Double.parseDouble(line))); }
					catch (NumberFormatException nfe) { continue; }
					break;
				case 3:
					out.print("Enter Key Code: ");
					line = in.nextLine();
					Message[] result = controller.requestItem(line);
					for (Message m : result) {
						out.println(m);
					}
					break;
				case 4:
					BigDecimal change = controller.requestChange();
					out.printf("Received %s back\n", NumberFormat.getCurrencyInstance().format(change.doubleValue()));
					break;
			}
		} while (selection != 5);
	}
	
	private static void printMenu() {
		out.println();
		out.printf("    Current Cash: %s\n", NumberFormat.getCurrencyInstance().format(controller.getCash().doubleValue()));
		out.println("[1] Check Available Items");
		out.println("[2] Add Cash");
		out.println("[3] Enter Key Code");
		out.println("[4] Refund Money");
		out.println("[5] Leave");
		out.print("> ");
	}
	
	private static void setupMachine() {
		List<Shelf> shelves = new ArrayList<Shelf>();
		shelves.add(setupShelf(
				setupSlot("E0", 1.25, "Cinnamon Bun", 9),
				setupSlot("E2", 1.25, "Corn Chips", 3),
				setupSlot("E4", 1.25, "Cheesy Chips", 8),
				setupSlot("E6", 1.25, "Trail Mix", 11),
				setupSlot("E8", 1.25, "Potato Strings", 7)
			));
		VendingMachine defaultMachine = new DefaultVendingMachine(new BigDecimal(32.25), shelves);
		controller = new VendingMachineController(defaultMachine, new VendingMachineConsoleView(defaultMachine));
	}
	
	private static Shelf setupShelf(ShelfSlot...slots) {
		Shelf shelf = new DefaultShelf();
		for (ShelfSlot slot : slots) {
			shelf.addSlot(slot);
		}
		return shelf;
	}

	private static ShelfSlot setupSlot(String keyCode, double price, String name, int count) {
		ShelfSlot slot = new DefaultShelfSlot(keyCode, new BigDecimal(price));
		for (int i = 0; i < count; i++) {
			slot.addLast(new DefaultVendingMachineItem(name));
		}
		return slot;
	}
}
