package bshields.istation.interfaces;

import java.math.BigDecimal;
import java.util.List;

public interface VendingMachine {
	
	List<Shelf> getShelves();
	
	void addShelf(Shelf shelf);
	
	void addShelf(Shelf shelf, int index);
	
	boolean removeShelf(Shelf shelf);
	
	Shelf removeShelf(int index);
	
	BigDecimal getCash();
	void addCash(BigDecimal cash);
	BigDecimal refundCash();
	void chargeCash(BigDecimal charge);
	BigDecimal getReserve();
}
