package bshields.istation.interfaces;

public interface VendingMachineView {
	void showVendingMachine();
}
