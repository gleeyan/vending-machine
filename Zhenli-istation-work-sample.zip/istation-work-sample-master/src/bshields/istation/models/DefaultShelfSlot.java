package bshields.istation.models;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.LinkedList;
import java.util.List;

import bshields.istation.interfaces.ShelfSlot;
import bshields.istation.interfaces.VendingMachineItem;

public class DefaultShelfSlot implements ShelfSlot {
	private LinkedList<VendingMachineItem> items;
	private BigDecimal price;
	private String keyCode;
	
	public DefaultShelfSlot(String keyCode) { this(keyCode, BigDecimal.ZERO, new LinkedList<VendingMachineItem>()); }
	
	public DefaultShelfSlot(String keyCode, BigDecimal price) { this(keyCode, price, new LinkedList<VendingMachineItem>()); }
	
	public DefaultShelfSlot(String keyCode, BigDecimal price, List<VendingMachineItem> items) {
		this.keyCode = keyCode;
		this.price = price;
		this.items = new LinkedList<VendingMachineItem>(items);
	}
	
	@Override
	public void addFirst(VendingMachineItem item) { items.addFirst(item); }
	@Override
	public void addLast(VendingMachineItem item) { items.addLast(item); }

	@Override
	public VendingMachineItem removeFirst() { return items.removeFirst(); }
	@Override
	public VendingMachineItem removeLast() { return items.removeLast(); }

	@Override
	public VendingMachineItem peek() { return items.peek() == null ? null : items.peek().newInstance(); }

	@Override
	public BigDecimal getPrice() { return price; }
	@Override
	public void setPrice(BigDecimal price) { this.price = price; }
	
	@Override
	public String getKeyCode() { return keyCode; }
	@Override
	public void setKeyCode(String keyCode) { this.keyCode = keyCode; }
	
	@Override
	public String toString() {
		return String.format("[%s] %s :: %s",
			getKeyCode(),
			NumberFormat.getCurrencyInstance().format(getPrice().doubleValue()),
			peek() == null ? "" : peek().getName());
	}
}
