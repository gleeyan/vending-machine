package bshields.istation.models;

import bshields.istation.interfaces.VendingMachineItem;

public class DefaultVendingMachineItem implements VendingMachineItem {
	private String name;
	
	public DefaultVendingMachineItem(String name) {
		this.name = name;
	}

	@Override
	public String getName() { return this.name; }
	@Override
	public void setName(String name) { this.name = name; }

	@Override
	public VendingMachineItem newInstance() { return new DefaultVendingMachineItem(name); }
}
