package bshields.istation.models;

public class Message {
	private String message;
	private Object tag;
	
	public Message(String message) { this(message, null); }
	
	public Message(String message, Object tag) {
		this.message = message;
		this.tag = tag;
	}
	
	public Object getTag() { return tag; }
	
	@Override
	public String toString() { return message; }
}
