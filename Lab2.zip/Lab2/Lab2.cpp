// Lab2.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <string>
#include <math.h>

using namespace std;

int main()
{

	//Number Bases
	int ibase;

	cout << "Please enter an integer to convert: ";
	cin >> ibase;
	cout << "The entered integer in octal         form is " << oct << ibase << endl;
	cout << "The entered integer in hexadecimal form is " << hex << ibase << endl;

	cout << dec;
	cout << endl << endl;

	int ishift;
	cout << "Please enter an integer to shift: ";
	cin >> ishift;
	cout << "This integer multiplied by 4 with left shift binary operator is:" << (ishift << 2) << endl;
	cout << "This integer divided    by 4 with right shift binary operator is" << (ishift >> 2) << endl;
	cout << endl << endl;




	cout << " char size:                   " << sizeof(char)     <<  endl;
	cout << "short size:                   " << sizeof(short)    << endl;
	cout << "int size:                     " << sizeof(int)      << endl;
	cout << "unsigned size:                " << sizeof(unsigned) << endl;
	cout << "long size:                    " << sizeof(long)     << endl;
	cout << "bool size:                    " << sizeof(bool)     << endl;
	cout << "float size:                   " << sizeof(float)    << endl;
	cout << "double size:                  " << sizeof(double)   << endl;
	cout << endl << endl;



	unsigned int uInt;
	cout << "Please enter a negative number"; cin >> uInt;
	cout << "The unsigned int = " << uInt;
	cout << endl << endl;

	int i = 1;
	i = i / i++;
	cout << i << endl;

	i = 1;
	i = 1 * ++i;
	cout << i << endl;

	i = 1;
	i = (i = i + 1) + (i = i + 2);
	cout << i << endl;

	cout << endl << endl;

	bool a = true, b = true;
	a = (b = false) && (b++);
	cout << a << endl << endl << endl;


	int int01, int02;

	cout << "Please enter an 1st integer : "; cin >> int01;
	cout << "Please enter a 2nd integer  : "; cin >> int02;
	cout << endl;

	cout << "The entered 1st integer is :  " << int01 << endl;
	cout << "The entered 2nd ineger is  :  " << int02 << endl;

	cout << "The sum of the two entered integers is: " << (int01 + int02) << endl;
	cout << "The product of the two entered integers is: " << (int01 * int02) << endl;
	cout << "The whole number quotient 1st/2nd is: " << (int01 / int02) << endl;
	cout << "The resultant remainder 1st/2nd is: " << (int01 % int02) << endl;
	cout << "1st float resultant remainder 1st/2nd is: " << (int01 / (float)int02) << endl;
	cout << "1st integer to the power of the 2nd is: " << (pow(int01, int02)) << endl;
	cout << endl << endl;

	float float01, float02;

	cout << "Please enter a 1st real number: "; cin >> float01;
	cout << "Please enter a 2nd real number: "; cin >> float02;
	cout << endl;

	cout << " The entered real numbers are: " << float01 << "," << float02 << endl;
	cout << "The sum of thses two real numbers is: " << (float01 + float02) << endl;
	cout << "The difference of these real numbers is: " << (float01 - float02) << endl;
	cout << "The product of these two real numbers is:" << (float01 * float02) << endl;
	cout << "The quotient of thses two real numbers is: " << (float01 / float02) << endl;
	cout << "The whole number part of 1st real numbers: " << ((int)float01) << endl;
	cout << "The whole number part of 2nd number is: " << ((int)float02) << endl;
	cout << "The fractional part of the 1st numbers is: " << (float01 - int(float01)) << endl;
	cout << "The fractional part of the 2nd numbers is: " << (float02 - int(float02)) << endl;
	cout << endl << endl;

	int anInteger;
	cout << "Please enter an Integer to convert to a float  ;"; cin >> anInteger;

	cout << "The integer as a float = " << (float)anInteger << endl;
	cout << endl;

	float afloat;
	cout << "Please enter a  float to convert to an integer: "; cin >> afloat;
	cout << " The float as a integer = " << (int)afloat << endl;
	cout << endl << endl << endl;

	string string01, string02;

	cout << "Please enter 1st string: "; cin >> string01;
	cout << endl;

	cout << "The 1st string is: " << string01 << endl;
	cout << " The first letter of this string is: " << string01.at(0) << endl;
	cout << "The length of this string is: " << string01.length() << endl;
	cout << "THe last letter of this string is: " << string01.at(string01.length() - 1) << endl << endl;

	cout << "Please enter a 2nd string: "; cin >> string02;
	cout << "The 1st string concatenated with the second string with a space in between is: " << string01 << " " << string02 << endl;

	return 0;


}

