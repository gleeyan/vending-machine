package bshields.istation.interfaces;

import java.util.List;

public interface Shelf {
	
	List<ShelfSlot> getSlots();
	
	void addSlot(ShelfSlot slot);
	
	void addSlot(ShelfSlot slot, int index);
	
	boolean removeSlot(ShelfSlot slot);
	
	ShelfSlot removeSlot(int index);
}
