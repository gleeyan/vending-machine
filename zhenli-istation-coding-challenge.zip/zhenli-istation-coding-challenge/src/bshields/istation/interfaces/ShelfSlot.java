package bshields.istation.interfaces;

import java.math.BigDecimal;

public interface ShelfSlot {
	
	void addFirst(VendingMachineItem item);
	
	void addLast(VendingMachineItem item);
	
	VendingMachineItem removeFirst();
	
	VendingMachineItem removeLast();
	
	VendingMachineItem peek();
	
	BigDecimal getPrice();
	void setPrice(BigDecimal price);
	
	String getKeyCode();
	void setKeyCode(String keyCode);
}
