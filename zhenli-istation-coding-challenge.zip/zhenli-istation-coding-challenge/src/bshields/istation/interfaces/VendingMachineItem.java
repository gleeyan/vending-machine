package bshields.istation.interfaces;

public interface VendingMachineItem {
	String getName();
	void setName(String name);
	
	VendingMachineItem newInstance();
}
