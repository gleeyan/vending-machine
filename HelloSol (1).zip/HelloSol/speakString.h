using namespace std;

bool speakString(string inputLineString) {

	// convert to wide string
	wstring wideString;
	wideString.assign(inputLineString.begin(), inputLineString.end());
	LPCTSTR LPCTSTRString = wideString.c_str();

	ISpVoice * pVoice = NULL;
	if (FAILED(::CoInitialize(NULL)))
		return false;
	HRESULT hr = CoCreateInstance(CLSID_SpVoice, NULL, CLSCTX_ALL, IID_ISpVoice, (void **)&pVoice);
	if (SUCCEEDED(hr)) {
		hr = pVoice->Speak(LPCTSTRString, 0, NULL);
		pVoice->Release();
		pVoice = NULL;
	}
	::CoUninitialize();

	return true;
}