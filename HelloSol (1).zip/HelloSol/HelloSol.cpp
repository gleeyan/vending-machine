// HelloSol.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include<iostream>
#include <string>
#include <sapi.h>

using namespace std;

#include "speakString.h"

int main(){
	string inputLineString;

	cout << "Hello Alien! How's life on Mars? " << endl;
	getline(cin, inputLineString);

	cout << inputLineString << endl;
	speakString(inputLineString);

	cout << "The-The-The That's all Folks";
	speakString("The-The-The That's all Folks");

	system("pause"); 

    return true;
}

